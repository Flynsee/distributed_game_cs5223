package Trash;

public class ImpossibleCreation extends Exception{
	public ImpossibleCreation(String string) {
		super(string);
	}
	private static final long serialVersionUID = 1L;
}
