package Game;

public enum Direction{
	NORTH, SOUTH, NOMOVE, EAST, WEST;
}
