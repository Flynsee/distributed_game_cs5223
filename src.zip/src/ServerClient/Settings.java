package ServerClient;

public class Settings {
	public static int serverPort=9000;
	public static String serverName="server";
	public static String serverHost="localhost";
}
