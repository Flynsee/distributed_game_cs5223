package Signal;

public interface Listener{
	public void event();
}
